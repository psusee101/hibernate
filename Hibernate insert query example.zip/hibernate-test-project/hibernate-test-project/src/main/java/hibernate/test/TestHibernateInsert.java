package hibernate.test;

import hibernate.test.dto.EmployeeEntity;

import org.hibernate.Session;

public class TestHibernateInsert {
	
	public static void main(String[] args) 
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
       
		//Add new Employee object
		EmployeeEntity emp = new EmployeeEntity();
		emp.setEmail("lokesh@mail.com");
		emp.setFirstName("lokesh");
		emp.setLastName("gupta");
		
		session.save(emp);

		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}

}
